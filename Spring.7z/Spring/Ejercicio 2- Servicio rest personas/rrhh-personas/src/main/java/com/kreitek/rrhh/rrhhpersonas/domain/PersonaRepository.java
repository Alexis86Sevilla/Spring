package com.kreitek.rrhh.rrhhpersonas.domain;

import org.springframework.data.repository.CrudRepository;

public interface PersonaRepository extends CrudRepository<Persona, Integer> {
}
