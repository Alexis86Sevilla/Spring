package com.kreitek.rrhh.rrhhpersonas.application;

import com.kreitek.rrhh.rrhhpersonas.domain.Persona;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;
@Mapper(componentModel = "spring")
public abstract class PersonaMapper {

       public abstract PersonaDTO personaToPersonaDto(Persona persona);
       public abstract Persona personaDtoToPersona(PersonaDTO persona);

}

