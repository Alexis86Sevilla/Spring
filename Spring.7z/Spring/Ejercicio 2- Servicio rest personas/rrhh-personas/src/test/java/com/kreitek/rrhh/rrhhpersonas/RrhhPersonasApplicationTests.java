package com.kreitek.rrhh.rrhhpersonas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RrhhPersonasApplicationTests {

	@Test
	void contextLoads() {
	}

}
