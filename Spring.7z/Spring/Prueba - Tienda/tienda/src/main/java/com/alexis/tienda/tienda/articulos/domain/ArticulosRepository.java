package com.alexis.tienda.tienda.articulos.domain;


import org.springframework.data.repository.CrudRepository;

public interface ArticulosRepository extends CrudRepository<Articulos, Integer> {
}
