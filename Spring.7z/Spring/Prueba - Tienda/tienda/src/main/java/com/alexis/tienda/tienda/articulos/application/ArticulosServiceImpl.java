package com.alexis.tienda.tienda.articulos.application;

import com.alexis.tienda.tienda.articulos.domain.Articulos;

import java.util.ArrayList;
import java.util.List;

public class ArticulosServiceImpl implements ArticulosService{

    @Override
    public List<Articulos> getArticulos() {
        List<Articulos> articulos = new ArrayList<>();
        personaRepository.findAll().forEach(persona -> personas.add(this.mapper.personaToPersonaDto(persona)));
        return personas;
    }
}
