package com.alexis.tienda.tienda.articulos.application;

import com.alexis.tienda.tienda.articulos.domain.Articulos;

import java.util.List;

public interface ArticulosService {
    List<Articulos> getArticulos();
}
