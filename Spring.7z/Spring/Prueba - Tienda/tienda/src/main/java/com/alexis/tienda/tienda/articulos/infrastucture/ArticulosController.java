package com.alexis.tienda.tienda.articulos.infrastucture;

import com.alexis.tienda.tienda.articulos.application.ArticulosService;
import com.alexis.tienda.tienda.articulos.domain.Articulos;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.List;

@RestController
public class ArticulosController {
    private HttpServletRequest request;
    private ArticulosService articulosService;

    public ArticulosController(HttpServletRequest request, ArticulosService articulosService) {
        this.request = request;
        this.articulosService = articulosService;
    }

    @GetMapping("/articulo")
    public ResponseEntity<List<Articulos>> getArticulos(){
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")){
            List<Articulos> articulos = articulosService.getArticulos();
            return new ResponseEntity<>(articulos, HttpStatus.OK);
        }
        return new ResponseEntity<List<Articulos>>(HttpStatus.NOT_IMPLEMENTED);
    }
}
