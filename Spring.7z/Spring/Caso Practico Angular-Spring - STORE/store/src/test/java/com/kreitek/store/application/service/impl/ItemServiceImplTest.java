package com.kreitek.store.application.service.impl;

import com.kreitek.store.application.dto.ItemDTO;
import com.kreitek.store.application.mapper.ItemMapperImpl;
import com.kreitek.store.domain.entity.Item;
import com.kreitek.store.domain.persistence.ItemPersistance;
import org.junit.jupiter.api.Test;
import org.mockito.stubbing.OngoingStubbing;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class ItemServiceImplTest {

    @Test
    void should_return_empty_list_when_there_are_no_items() {
        ItemPersistance mockedItemRepository = mock(ItemPersistance.class);
        when(mockedItemRepository.getAllItems()).thenReturn(new ArrayList<>());

        ItemServiceImpl itemService = new ItemServiceImpl(mockedItemRepository, new ItemMapperImpl());

        List<ItemDTO> itemDTOS = itemService.getAllItems();

        assertNotNull(itemDTOS);
        assertEquals(0, itemDTOS.size());

    }

    @Test
    void should_return_list_of_item_when_there_are_2_items() {
        ItemPersistance mockedItemRepository = mock(ItemPersistance.class);

        List<Item> items = new ArrayList<>();
        items.add(createItem(1L, "vans", "ultima generación"));
        items.add(createItem(2L, "converse", "de las mejores"));

        when(mockedItemRepository.getAllItems()).thenReturn(items);

        ItemServiceImpl itemService = new ItemServiceImpl(mockedItemRepository, new ItemMapperImpl());

        List<ItemDTO> itemDTOS = itemService.getAllItems();

        assertNotNull(itemDTOS);
        assertEquals(2, itemDTOS.size());

    }


    @Test
    void should_return_null_object_when_id_not_exist() {
        ItemPersistance mockedItemRepository = mock(ItemPersistance.class);


        when(mockedItemRepository.getItemById(1L)).thenReturn(Optional.of(createItem
                (1L, "vans", "ultima generación")));

        ItemServiceImpl itemService = new ItemServiceImpl(mockedItemRepository, new ItemMapperImpl());

        Optional<ItemDTO> itemDTO = itemService.getItemById(1L);

        assertNotNull(itemDTO);
        assertTrue(itemDTO.isPresent());
        Optional<ItemDTO> expectedItemDTO = Optional.of(createItemDTO(1L, "vans", "ultima generación"));


    }

    @Test
    void should_return_item_when_id_exist() {
        ItemPersistance mockedItemRepository = mock(ItemPersistance.class);

        when(mockedItemRepository.getItemById(2L)).thenReturn(Optional.empty());

        ItemServiceImpl itemService = new ItemServiceImpl(mockedItemRepository, new ItemMapperImpl());

        Optional<ItemDTO> itemDTO = itemService.getItemById(2L);

        assertNotNull(itemDTO);
        assertFalse(itemDTO.isPresent());


    }


    private Item createItem(Long id, String nombre, String descripcion) {
        Item item = new Item();
        item.setId(id);
        item.setName(nombre);
        item.setDescription(descripcion);
        return item;
    }

    private ItemDTO createItemDTO(Long id, String nombre, String descripcion) {
        ItemDTO item = new ItemDTO();
        item.setId(id);
        item.setName(nombre);
        item.setDescription(descripcion);
        return item;
    }
}