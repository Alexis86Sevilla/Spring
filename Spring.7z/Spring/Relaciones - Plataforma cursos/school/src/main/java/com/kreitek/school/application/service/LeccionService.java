package com.kreitek.school.application.service;

import com.kreitek.school.application.dto.AdjuntoDTO;
import com.kreitek.school.application.dto.LeccionDTO;
import com.kreitek.school.domain.entity.Adjunto;
import com.kreitek.school.domain.entity.Leccion;

import java.util.List;
import java.util.Optional;

public interface LeccionService {

    List<LeccionDTO> obtenerLeccionesCurso(Long cursoId);
    LeccionDTO crearLeccion(Long cursoId, LeccionDTO leccion);
    Optional<LeccionDTO> obtenerLeccionCurso(Long cursoId, Long leccionId);
    List<AdjuntoDTO> adjuntarFichero(Long cursoId, Long leccionId, AdjuntoDTO adjuntoDTO);
}
