package com.kreitek.school.application.dto;

import javax.persistence.*;
import java.io.Serializable;
import java.util.List;

public class CuestionarioDTO implements Serializable {

    private Long id;
    private String titulo;
    private String notaMinima;
    private List<PreguntaCuestionarioDTO> preguntas;

    public CuestionarioDTO() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getNotaMinima() {
        return notaMinima;
    }

    public void setNotaMinima(String notaMinima) {
        this.notaMinima = notaMinima;
    }

    public List<PreguntaCuestionarioDTO> getPreguntas() {
        return preguntas;
    }

    public void setPreguntas(List<PreguntaCuestionarioDTO> preguntas) {
        this.preguntas = preguntas;
    }
}
