package com.kreitek.school.application.mapper;

import com.kreitek.school.application.dto.CursoDTO;
import com.kreitek.school.application.dto.LeccionDTO;
import com.kreitek.school.domain.entity.Curso;
import com.kreitek.school.domain.entity.Leccion;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring", uses = {CursoMapper.class, ProfesorMapper.class})  //CON USES PERMITE CONVERTIR UNA LECCION A UN DTO Y CONOCER DATOS DEL CURSO DENTRO DE LECCION
public interface LeccionMapper extends EntityMapper<LeccionDTO, Leccion>{

    @Override
    @Mapping(source = "cursoId", target = "curso") //ES EL CAMINO INVERSO AL DE ABAJO
    @Mapping(source = "profesorId", target = "profesor")
    Leccion toEntity(LeccionDTO dto);

    @Override //SE INCLUYE AQUI PORQUE HAY QUE DARLE INSTRUCCIONES ESPECIALES
    @Mapping(source = "curso.id", target = "cursoId")
    @Mapping(source = "curso.nombre",  target = "cursoNombre")
    @Mapping(source = "profesor.id", target = "profesorId")
    @Mapping(source = "profesor.nombre", target = "profesorNombre")
    LeccionDTO toDTO(Leccion Entity);
}
