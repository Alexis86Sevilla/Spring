package com.kreitek.school.application.service.impl;

import com.kreitek.school.application.dto.AlumnoDTO;
import com.kreitek.school.application.dto.CursoSimpleDTO;
import com.kreitek.school.application.mapper.AlumnoMapper;
import com.kreitek.school.application.service.AlumnoService;
import com.kreitek.school.domain.entity.Alumno;
import com.kreitek.school.infraestructure.repository.AlumnoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import org.springframework.transaction.annotation.Transactional;
import java.util.List;
import java.util.Optional;

@Service
public class AlumnoServiceImpl implements AlumnoService {

    private AlumnoRepository alumnoRepository;
    private AlumnoMapper alumnoMapper;

    @Autowired
    public AlumnoServiceImpl(AlumnoRepository alumnoRepository, AlumnoMapper alumnoMapper) {
        this.alumnoRepository = alumnoRepository;
        this.alumnoMapper = alumnoMapper;
    }

    @Override
    @Transactional(readOnly = true)
    public List<AlumnoDTO> obtenerAlumnos() {
        var alumnos = alumnoRepository.findAll();
        return alumnoMapper.toDto(alumnos);
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<AlumnoDTO> obtenerAlumnoPorId(Long id) {
        return alumnoRepository
                .findById(id)
                .map(alumnoMapper::toDTO);
    }

    @Override
    @Transactional
    public AlumnoDTO crearAlumno(AlumnoDTO alumnoDTO) {
        var alumno = alumnoMapper.toEntity(alumnoDTO);
        alumno=alumnoRepository.save(alumno);
        return alumnoMapper.toDTO(alumno);
    }

    @Override
    public void eliminarAlumnoPorId(Long alumnoId) {
        alumnoRepository.deleteById(alumnoId);
    }

    @Override
    @Transactional
    public List<CursoSimpleDTO> registrarAlumnoEnCurso(Long alumnoId, CursoSimpleDTO cursoSimpleDTO) {
        AlumnoDTO alumnoDTO = obtenerAlumnoPorId(alumnoId)
                .orElseThrow(() -> new RuntimeException("Alumno no existe"));
        alumnoDTO.getCursos().add(cursoSimpleDTO);
        Alumno alumno = alumnoRepository.save(alumnoMapper.toEntity(alumnoDTO));
        alumnoDTO = alumnoMapper.toDTO(alumno);
        return alumnoDTO.getCursos();
    }

    @Override
    @Transactional
    public void eliminarCursoDeAlumno(Long alumnoId, Long cursoId) {
        Alumno alumno = alumnoRepository
                .findById(alumnoId)
                .orElseThrow(() -> new RuntimeException("Alumno no encontrado"));
        alumno.eliminarCursoPorId(cursoId);
        alumnoRepository.save(alumno);
    }


}
