package com.kreitek.school.application.service.impl;

import com.kreitek.school.application.dto.CursoDTO;
import com.kreitek.school.application.mapper.CursoMapper;
import com.kreitek.school.application.service.CursoService;
import com.kreitek.school.domain.entity.Curso;
import com.kreitek.school.infraestructure.repository.CursoRepository;
import org.mapstruct.Mapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


import java.util.List;
import java.util.Optional;

@Service
public class CursoServiceImpl implements CursoService {
//CLASE QUE IMPLEMENTA Y DESARROLLA TODOS LOS METODOS DE CURSOSERVICE
    private final CursoRepository cursoRepository;
    private final CursoMapper cursoMapper;

    @Autowired
    public CursoServiceImpl(CursoRepository cursoRepository, CursoMapper cursoMapper) {
        this.cursoRepository = cursoRepository;
        this.cursoMapper = cursoMapper;
    }

    @Override
    @Transactional(readOnly = true)
    public List<CursoDTO> obtenerCursos() {
        List<Curso> cursos = cursoRepository.findAll(); //SE CREA UNA LISTA CUYO CONTENIDO SERA EL HABER ENCONTRADO LOS CURSOS
        return cursoMapper.toDto(cursos); //SE TRANSFORMA EN DTO
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<CursoDTO> obtenerCurso(Long id) {
       return cursoRepository
               .findById(id)
               .map(curso -> cursoMapper.toDTO(curso)); //PARA DEVOLVER UN CURSO POR ID Y SI LO ENCUENTRA, PASAR A DTO

    }

    @Override
    @Transactional
    public CursoDTO crearCurso(CursoDTO cursoDTO) {
        Curso curso = cursoMapper.toEntity(cursoDTO); //SE TRANSFORMA EL CURSODTO A ENTIDAD
        curso = cursoRepository.save(curso); //SE GUARDA LA ENTIDAD
        return cursoMapper.toDTO(curso); //SE DEVUELVE LA ENTIDAD A DTO
    }

    @Override
    @Transactional
    public void eliminarCurso(Long id) {
        cursoRepository.deleteById(id); //SE BORRA POR ID
    }
}
