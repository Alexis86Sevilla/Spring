package com.kreitek.school.infraestructure.rest;

import com.kreitek.school.application.dto.AdjuntoDTO;
import com.kreitek.school.application.dto.LeccionDTO;
import com.kreitek.school.application.service.LeccionService;
import com.kreitek.school.domain.entity.Adjunto;
import com.kreitek.school.domain.entity.Leccion;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/cursos/{cursoId}")
public class LeccionRestController {

    private final LeccionService leccionService;

    @Autowired
    public LeccionRestController(LeccionService leccionService) {
        this.leccionService = leccionService;
    }

    @GetMapping(value = "/lecciones", produces = "application/json")
    public ResponseEntity<List<LeccionDTO>> obtenerLeccionesCurso(@PathVariable Long cursoId) {
        List<LeccionDTO> leccionesDto = leccionService.obtenerLeccionesCurso(cursoId);
        return new ResponseEntity<>(leccionesDto, HttpStatus.OK);
    }

    @GetMapping(value = "/lecciones/{leccionesId}", produces = "application/json")
    public ResponseEntity<LeccionDTO> obtenerLeccionCurso(@PathVariable Long cursoId, @PathVariable Long leccionId) {
        return leccionService.obtenerLeccionCurso(cursoId, leccionId)
                .map(leccionDTO -> new ResponseEntity(leccionDTO, HttpStatus.OK))
                .orElse(new ResponseEntity(HttpStatus.NOT_FOUND));
    }

    @PostMapping(value = "/lecciones", produces = "application/json", consumes = "application/json")
    public ResponseEntity<LeccionDTO> crearLeccionCurso(@PathVariable Long cursoId, @RequestBody LeccionDTO leccionDto) {
        leccionDto = leccionService.crearLeccion(cursoId, leccionDto);
        return new ResponseEntity<>(leccionDto, HttpStatus.CREATED);
    }

    @PutMapping(value = "/lecciones/{leccionId}/adjuntos", produces = "application/json", consumes = "application/json")
    public ResponseEntity<List<AdjuntoDTO>> anadirAdjuntoEnLeccion(@PathVariable Long cursoId,
                                                                   @PathVariable Long leccionId,
                                                                   @RequestBody AdjuntoDTO adjuntoDTO) {
        List<AdjuntoDTO> adjuntoDtos = leccionService.adjuntarFichero(cursoId, leccionId, adjuntoDTO);
        return new ResponseEntity<>(adjuntoDtos, HttpStatus.OK);
    }

}
