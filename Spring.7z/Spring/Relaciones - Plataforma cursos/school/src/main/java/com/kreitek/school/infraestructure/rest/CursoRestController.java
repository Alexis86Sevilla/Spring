package com.kreitek.school.infraestructure.rest;

import com.kreitek.school.application.dto.CursoDTO;
import com.kreitek.school.application.service.CursoService;
import com.kreitek.school.domain.entity.Curso;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class CursoRestController {
//CONTROLADOR PARA GENERAR TODOS LOS ENDPOINTS
    private final CursoService cursoService;

    @Autowired
    public CursoRestController(CursoService cursoService) {
        this.cursoService = cursoService;
    }

    @GetMapping(value = "/cursos", produces = "application/json")
    public ResponseEntity<List<CursoDTO>> obtenerCursos(){
        List<CursoDTO> cursosDTO = cursoService.obtenerCursos(); //SE GUARDAN LOS CURSOS EN UNA LISTA MEDIANTE LA FUNCION DEL SERVICIO
        return new ResponseEntity<>(cursosDTO, HttpStatus.OK);
    }

    @GetMapping(value = "/cursos/{cursoId}", produces = "application/json")
    public ResponseEntity<CursoDTO> obtenerCurso(@PathVariable Long cursoId) //PATHVARIABLE ES PARA ESPECIFICAR QUE SE VA A RECIBIR UN PARAMETRO ¡¡¡EN LA RUTA!!!
    {
      return cursoService.obtenerCurso(cursoId) //SE INICIA EL METODO DE OBTENER CURSO
                .map(cursoDTO -> new ResponseEntity(cursoDTO, HttpStatus.OK))  //SI ENCUENTRA ALGO DEVUELVE UN CURSODTO
                .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND)); //SI NO ENCUENTRA NADA, DEVUELVE UN NOT FOUND
    }

    @PostMapping(value = "/cursos", produces = "application/json", consumes = "application/json") //CONSUMES ES LO QUE VA A RECIBIR
    public ResponseEntity<CursoDTO> crearCurso(@RequestBody CursoDTO cursoDTO) //EL REQUEST BODY ES LO QUE VA A TENER EL CUERPO, UN CURSO
    {
        cursoDTO = cursoService.crearCurso(cursoDTO);
        return new ResponseEntity<>(cursoDTO, HttpStatus.CREATED);
    }

    @DeleteMapping(value = "/curso/{cursoId}")
    public ResponseEntity<Void> eliminarCurso(@PathVariable Long cursoId){
        cursoService.eliminarCurso(cursoId);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
