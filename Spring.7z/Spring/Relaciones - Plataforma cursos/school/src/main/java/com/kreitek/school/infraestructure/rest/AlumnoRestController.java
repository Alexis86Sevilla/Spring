package com.kreitek.school.infraestructure.rest;

import com.kreitek.school.application.dto.AlumnoDTO;
import com.kreitek.school.application.dto.CursoSimpleDTO;
import com.kreitek.school.application.service.AlumnoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class AlumnoRestController {

    private final AlumnoService alumnoService;

    @Autowired
    public AlumnoRestController(AlumnoService alumnoService) {
        this.alumnoService = alumnoService;
    }

    @GetMapping(value = "/alumnos", produces = "application/json")
    public ResponseEntity<List<AlumnoDTO>> obtenerAlumnos(){
        var alumnos = alumnoService.obtenerAlumnos();
        return new ResponseEntity<>(alumnos, HttpStatus.OK);
    }

    @GetMapping(value = "/alumnos/{alumnoId}", produces = "application/json")
    public ResponseEntity<AlumnoDTO> obtenerAlumnoPorId(@PathVariable Long alumnoId){
        return alumnoService
                .obtenerAlumnoPorId(alumnoId)
                .map(AlumnoDTO -> new ResponseEntity<>(AlumnoDTO, HttpStatus.OK))
                .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    @PostMapping(value = "/alumnos", produces = "application/json", consumes = "application/json")
    public ResponseEntity<AlumnoDTO> crearAlumno(@RequestBody AlumnoDTO alumnoDTO){
        alumnoDTO = alumnoService.crearAlumno(alumnoDTO);
        return new ResponseEntity<>(alumnoDTO, HttpStatus.CREATED);
    }

    @DeleteMapping(value = "/alumnos/{alumnoId}", produces = "application/json")
    public ResponseEntity<Void> eliminarAlummnoPorId(@PathVariable Long alumnoId){
        alumnoService.eliminarAlumnoPorId(alumnoId);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    @PutMapping(value = "/alumnos/{alumnoId}/cursos", produces = "application/json", consumes = "application/json")
    public ResponseEntity<List<CursoSimpleDTO>> registrarAlumnoEnCurso(@PathVariable Long alumnoId, @RequestBody CursoSimpleDTO cursoSimpleDTO){
        List<CursoSimpleDTO> cursoSimpleDTOS = alumnoService.registrarAlumnoEnCurso(alumnoId, cursoSimpleDTO);
        return new ResponseEntity<>(cursoSimpleDTOS, HttpStatus.OK);
    }

    @DeleteMapping(value = "/alumnos/{alumnoId}/cursos/{cursoId}")
    public ResponseEntity<Void> eliminarCursoDeAlumno(@PathVariable Long alumnoId, Long cursoId){
        alumnoService.eliminarCursoDeAlumno(alumnoId, cursoId);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }


}
