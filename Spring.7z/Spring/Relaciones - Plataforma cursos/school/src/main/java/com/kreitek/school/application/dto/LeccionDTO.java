package com.kreitek.school.application.dto;

import java.io.Serializable;
import java.util.List;
import java.util.Objects;

public class LeccionDTO implements Serializable {

    private Long id;
    private String titulo;
    private String contenido;
    private Integer orden;
    //NO SE CREA UNA LISTA DE CURSOS PARA QUE NO SE GENERE UN BUCLE
    //SE CREAN CAMPOS PARA OBTENER MAS INFO SOBRE LOS CURSOS RELACIONADOS CON LECCIONES

    private Long cursoId;
    private String cursoNombre;

    private Long profesorId;
    private String profesorNombre;

    List<AdjuntoDTO> adjuntos;

    public LeccionDTO() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getContenido() {
        return contenido;
    }

    public void setContenido(String contenido) {
        this.contenido = contenido;
    }

    public Integer getOrden() {
        return orden;
    }

    public void setOrden(Integer orden) {
        this.orden = orden;
    }

    public Long getCursoId() {
        return cursoId;
    }

    public void setCursoId(Long cursoId) {
        this.cursoId = cursoId;
    }

    public String getCursoNombre() {
        return cursoNombre;
    }

    public void setCursoNombre(String cursoNombre) {
        this.cursoNombre = cursoNombre;
    }

    public Long getProfesorId() {
        return profesorId;
    }

    public void setProfesorId(Long profesorId) {
        this.profesorId = profesorId;
    }

    public String getProfesorNombre() {
        return profesorNombre;
    }

    public void setProfesorNombre(String profesorNombre) {
        this.profesorNombre = profesorNombre;
    }

    public List<AdjuntoDTO> getAdjuntos() {
        return adjuntos;
    }

    public void setAdjuntos(List<AdjuntoDTO> adjuntos) {
        this.adjuntos = adjuntos;
    }

    //SE HACE OVERRIDE SOBRE ESTOS METODOS
    @Override
    public int hashCode() {
        return Objects.hash(id, titulo, contenido, orden);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        LeccionDTO o = (LeccionDTO) obj;
        return Objects.equals(this.id, o.id) &&
                Objects.equals(this.titulo, o.titulo) &&
                Objects.equals(this.contenido, o.contenido) &&
                Objects.equals(this.orden, o.orden);
    }

    //POR SI QUEREMOS DEVOLVER LOS VALORES DEL DTO

    @Override
    public String toString() {
        return "LeccionDTO{" +
                "id=" + id +
                ", titulo='" + titulo + '\'' +
                ", contenido='" + contenido + '\'' +
                ", orden=" + orden +
                '}';
    }
}
