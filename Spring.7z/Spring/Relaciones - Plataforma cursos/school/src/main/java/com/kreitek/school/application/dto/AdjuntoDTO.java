package com.kreitek.school.application.dto;

import com.kreitek.school.domain.entity.Adjunto;

import javax.persistence.Column;
import javax.persistence.Lob;
import java.io.Serializable;

public class AdjuntoDTO implements Serializable {

    private Long id;
    private String nombre;
    private String mimeType;
    private byte[] contenido;

    public AdjuntoDTO() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getMimeType() {
        return mimeType;
    }

    public void setMimeType(String mimeType) {
        this.mimeType = mimeType;
    }

    public byte[] getContenido() {
        return contenido;
    }

    public void setContenido(byte[] contenido) {
        this.contenido = contenido;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass() || id == null) return false;
        AdjuntoDTO adjunto = (AdjuntoDTO) o;
        return id.equals(adjunto.id);
    }
}
