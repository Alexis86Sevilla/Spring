package com.kreitek.school.application.mapper;

import java.util.List;

//INTERFAZ QUE USARAN TODAS LAS ENTIDADES POR LO TANTO ES GENERICO
public interface EntityMapper<D, E> {
    E toEntity(D dto);
    D toDTO(E Entity);
    List<E> toEntity(List<D> dtolist);
    List<D> toDto(List<E> entityList);
}
