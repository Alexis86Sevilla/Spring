package com.kreitek.school.infraestructure.repository;

import com.kreitek.school.domain.entity.Curso;
import org.springframework.data.jpa.repository.JpaRepository;


public interface CursoRepository extends JpaRepository<Curso, Long> {
//ESTA ES UNA INTERFAZ QUE INCLUYE TODAS LAS ACCIONES DE JPA COMO FINDALL, FIND...
}
