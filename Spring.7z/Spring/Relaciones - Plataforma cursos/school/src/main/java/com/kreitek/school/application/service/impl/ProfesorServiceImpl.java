package com.kreitek.school.application.service.impl;

import com.kreitek.school.application.dto.ProfesorDTO;
import com.kreitek.school.application.mapper.ProfesorMapper;
import com.kreitek.school.application.service.ProfesorService;
import com.kreitek.school.domain.entity.Profesor;
import com.kreitek.school.infraestructure.repository.ProfesorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ProfesorServiceImpl implements ProfesorService {

    private final ProfesorRepository profesorRepository;
    private final ProfesorMapper profesorMapper;

    @Autowired
    public ProfesorServiceImpl(ProfesorRepository profesorRepository, ProfesorMapper profesorMapper) {
        this.profesorRepository = profesorRepository;
        this.profesorMapper = profesorMapper;
    }

    @Override
    public List<ProfesorDTO> obtenerProfesores() {
        List<Profesor> profesores = profesorRepository.findAll();
        return profesorMapper.toDto(profesores);
    }

    @Override
    public Optional<ProfesorDTO> obtenerProfesorPorId(Long profesorId) {
        return profesorRepository
                .findById(profesorId)
                .map(profesorMapper::toDTO);
    }

    @Override
    public ProfesorDTO crearProfesor(ProfesorDTO profesorDTO) {
        var profesor = profesorMapper.toEntity(profesorDTO);
        profesor = profesorRepository.save(profesor);
        return profesorMapper.toDTO(profesor);
    }
}
