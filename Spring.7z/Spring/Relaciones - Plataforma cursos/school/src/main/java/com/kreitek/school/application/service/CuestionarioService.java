package com.kreitek.school.application.service;

import com.kreitek.school.application.dto.CuestionarioDTO;
import com.kreitek.school.application.dto.PreguntaCuestionarioDTO;
import com.kreitek.school.domain.entity.Cuestionario;

import java.util.List;
import java.util.Optional;

public interface CuestionarioService {
    List<CuestionarioDTO> obtenerCuestionarios();
    Optional<CuestionarioDTO> obtenerCuestionarioPorId(Long id);
    CuestionarioDTO crearCuestionario(CuestionarioDTO cuestionarioDTO);
    List<PreguntaCuestionarioDTO> anadePreguntaEnCuestionario(Long cuestionarioId, PreguntaCuestionarioDTO preguntaCuestionarioDTO);
    List<PreguntaCuestionarioDTO> obtenerPreguntaCuestionario(Long cuestionarioId);
}
