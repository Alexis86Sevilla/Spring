package com.kreitek.school.infraestructure.rest;

import com.kreitek.school.application.dto.ProfesorDTO;
import com.kreitek.school.application.service.ProfesorService;
import com.kreitek.school.domain.entity.Profesor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class ProfesorRestController {

    private final ProfesorService profesorService;

    @Autowired
    public ProfesorRestController(ProfesorService profesorService) {
        this.profesorService = profesorService;
    }

    @GetMapping(value = "/profesores", produces = "application/json")
    public ResponseEntity<List<ProfesorDTO>> obtenerProfesores(){
        var profesores = profesorService.obtenerProfesores();
        return new ResponseEntity<>(profesores, HttpStatus.OK);
    }

    @GetMapping(value = "/profesores/{profesorId}", produces = "application/json")
    public ResponseEntity<ProfesorDTO> obtenerProfesor(@PathVariable Long profesorId){
        return profesorService
                .obtenerProfesorPorId(profesorId)
                .map(profesorDTO -> new ResponseEntity<>(profesorDTO, HttpStatus.OK))
                .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    @PostMapping(value = "/profesores", produces = "application/json", consumes = "application/json")
    public ResponseEntity<ProfesorDTO> crearProfesor(@RequestBody ProfesorDTO profesorDTO){
        profesorDTO = profesorService.crearProfesor(profesorDTO);
        return new ResponseEntity<>(profesorDTO, HttpStatus.CREATED);
    }


}
