package com.kreitek.school.application.service;

import com.kreitek.school.application.dto.AdjuntoDTO;

import java.util.List;
import java.util.Optional;

public interface AdjuntoService {
    List<AdjuntoDTO> obtenerAdjuntos();
    Optional<AdjuntoDTO> obtenerAdjuntoPorId(Long id);
    AdjuntoDTO crearAdjunto(AdjuntoDTO adjuntoDTO);
}
