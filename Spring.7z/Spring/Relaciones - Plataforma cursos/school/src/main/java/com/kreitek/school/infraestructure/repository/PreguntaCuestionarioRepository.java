package com.kreitek.school.infraestructure.repository;

import org.springframework.data.jpa.repository.JpaRepository;

public interface PreguntaCuestionarioRepository extends JpaRepository<PreguntaRepository, Long> {
}
