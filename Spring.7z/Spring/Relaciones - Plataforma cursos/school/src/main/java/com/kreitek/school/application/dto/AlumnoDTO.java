package com.kreitek.school.application.dto;

import java.io.Serializable;
import java.util.List;
import java.util.Objects;

public class AlumnoDTO implements Serializable {

    private Long id;
    private String nombre;
    private String url;
    private List<CursoSimpleDTO> cursos;

    public AlumnoDTO() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public List<CursoSimpleDTO> getCursos() {
        return cursos;
    }

    public void setCursos(List<CursoSimpleDTO> cursos) {
        this.cursos = cursos;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        AlumnoDTO alumnoDTO = (AlumnoDTO) o;
        return Objects.equals(id, alumnoDTO.id) && Objects.equals(nombre, alumnoDTO.nombre) && Objects.equals(url, alumnoDTO.url);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, nombre, url);
    }

    @Override
    public String toString() {
        return "AlumnoDTO{" +
                "id=" + id +
                ", nombre='" + nombre + '\'' +
                ", url='" + url + '\'' +
                '}';
    }
}
