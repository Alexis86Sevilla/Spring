package com.kreitek.school.application.dto;

import javax.persistence.Column;
import java.io.Serializable;

public class PreguntaDTO implements Serializable {

    private Long id;
    private String pregunta;
    private String respuesta;

    public PreguntaDTO() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getPregunta() {
        return pregunta;
    }

    public void setPregunta(String pregunta) {
        this.pregunta = pregunta;
    }

    public String getRespuesta() {
        return respuesta;
    }

    public void setRespuesta(String respuesta) {
        this.respuesta = respuesta;
    }
}
