package com.kreitek.school.application.mapper;

import com.kreitek.school.application.dto.ProfesorDTO;
import com.kreitek.school.domain.entity.Curso;
import com.kreitek.school.domain.entity.Profesor;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface ProfesorMapper extends EntityMapper<ProfesorDTO, Profesor> {

    default Profesor fromId(Long id){
        if (id == null) return null; //SI EL PROFESOR NO RECIBE ID DEVUELVE NULO
        Profesor profesor = new Profesor(); //SI LO RECIBE, DEVOLVERA UN PROFESOR CON ID
        profesor.setId(id);
        return profesor;
    }
}
