package com.kreitek.school.application.service.impl;

import com.kreitek.school.application.dto.AdjuntoDTO;
import com.kreitek.school.application.dto.LeccionDTO;
import com.kreitek.school.application.mapper.LeccionMapper;
import com.kreitek.school.application.service.LeccionService;
import com.kreitek.school.domain.entity.Adjunto;
import com.kreitek.school.domain.entity.Leccion;
import com.kreitek.school.infraestructure.repository.LeccionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


import java.util.List;
import java.util.Optional;

@Service
public class LeccionServiceImpl implements LeccionService {

    private final LeccionRepository leccionRepository;
    private final LeccionMapper leccionMapper;

    @Autowired
    public LeccionServiceImpl(LeccionRepository leccionRepository, LeccionMapper leccionMapper) {
        this.leccionRepository = leccionRepository;
        this.leccionMapper = leccionMapper;
    }

    @Override
    @Transactional(readOnly = true)
    public List<LeccionDTO> obtenerLeccionesCurso(Long cursoId) {
        List<Leccion> lecciones = leccionRepository.findAllByCurso_Id(cursoId);
        return leccionMapper.toDto(lecciones);
    }

    @Override
    @Transactional
    public LeccionDTO crearLeccion(Long cursoId, LeccionDTO leccionDTO) {
        leccionDTO.setCursoId(cursoId);
        Leccion leccion = leccionMapper.toEntity(leccionDTO);
        leccion = leccionRepository.save(leccion);
        return leccionMapper.toDTO(leccion);
    }

    @Override
    @Transactional
    public Optional<LeccionDTO> obtenerLeccionCurso(Long cursoId, Long leccionId) {
        return leccionRepository
                .findOneByIdAndCurso_Id(leccionId, cursoId)
                .map(leccionMapper::toDTO); //EXPRESION LAMBDA QUE ACORTA MUCHO
    }

    @Override
    @Transactional
    public List<AdjuntoDTO> adjuntarFichero(Long cursoId, Long leccionId, AdjuntoDTO adjuntoDTO) {
        LeccionDTO leccionDTO = obtenerLeccionCurso(cursoId,leccionId)
                .orElseThrow(() -> new RuntimeException("Lección no encontrada"));
        leccionDTO.getAdjuntos().add(adjuntoDTO);
        Leccion leccion = leccionRepository.save(leccionMapper.toEntity(leccionDTO));
        leccionDTO = leccionMapper.toDTO(leccion);

        return leccionDTO.getAdjuntos();
    }
}
