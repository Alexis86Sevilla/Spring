package com.kreitek.school.application.service;

import com.kreitek.school.application.dto.ProfesorDTO;

import java.util.List;
import java.util.Optional;

public interface ProfesorService {

    List<ProfesorDTO> obtenerProfesores();
    Optional<ProfesorDTO> obtenerProfesorPorId(Long profesorId);
    ProfesorDTO crearProfesor(ProfesorDTO profesorDTO);

}
