package com.kreitek.school.application.service;

import com.kreitek.school.application.dto.AlumnoDTO;
import com.kreitek.school.application.dto.CursoSimpleDTO;

import java.util.List;
import java.util.Optional;

public interface AlumnoService {
    List<AlumnoDTO> obtenerAlumnos();
    Optional<AlumnoDTO> obtenerAlumnoPorId(Long id);
    AlumnoDTO crearAlumno(AlumnoDTO alumnoDTO);
    void eliminarAlumnoPorId(Long alumnoId);
    List<CursoSimpleDTO> registrarAlumnoEnCurso(Long alumnoId, CursoSimpleDTO cursoSimpleDTO);
    void eliminarCursoDeAlumno(Long alumnoId, Long cursoId);
}
