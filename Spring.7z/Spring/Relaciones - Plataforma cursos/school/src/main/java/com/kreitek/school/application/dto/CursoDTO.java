package com.kreitek.school.application.dto;

import java.io.Serializable;
import java.util.List;
import java.util.Objects;

public class CursoDTO implements Serializable {
    //SE IMPLEMENTA SERIALIZABLE PARA QUE PUEDA RECIBIR JSON

    private Long id;
    private String nombre;
    private String resumen;
    private List<LeccionDTO> lecciones; //SE CREA UNA LISTA DE LECCIONES
    private List<AlumnoSimpleDTO> alumnos;

    //ES NECESARIO SIEMPRE UN CONSTRUCTOR POR DEFECTO
    public CursoDTO() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getResumen() {
        return resumen;
    }

    public void setResumen(String resumen) {
        this.resumen = resumen;
    }

    public List<LeccionDTO> getLecciones() {
        return lecciones;
    }

    public void setLecciones(List<LeccionDTO> lecciones) {
        this.lecciones = lecciones;
    }

    public List<AlumnoSimpleDTO> getAlumnos() {
        return alumnos;
    }

    public void setAlumnos(List<AlumnoSimpleDTO> alumnos) {
        this.alumnos = alumnos;
    }

    //SE HACE OVERRIDE SOBRE ESTOS METODOS
    @Override
    public int hashCode() {
        return Objects.hash(id, nombre, resumen);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        CursoDTO o = (CursoDTO) obj;
        return Objects.equals(this.id, o.id) &&
                Objects.equals(this.nombre, o.nombre) &&
                Objects.equals(this.resumen, o.resumen);
    }

    //POR SI QUEREMOS DEVOLVER LOS VALORES DEL DTO
    @Override
    public String toString() {
        return "CursoDTO{" +
                "id=" + id +
                ", nombre='" + nombre + '\'' +
                ", resumen='" + resumen + '\'' +
                '}';
    }
}
