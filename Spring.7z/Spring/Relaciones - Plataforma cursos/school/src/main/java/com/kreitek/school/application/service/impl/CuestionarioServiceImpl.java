package com.kreitek.school.application.service.impl;

import com.kreitek.school.application.dto.CuestionarioDTO;
import com.kreitek.school.application.dto.PreguntaCuestionarioDTO;
import com.kreitek.school.application.mapper.CuestionarioMapper;
import com.kreitek.school.application.service.CuestionarioService;
import com.kreitek.school.domain.entity.Cuestionario;
import com.kreitek.school.infraestructure.repository.CuestionarioRepository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

public class CuestionarioServiceImpl implements CuestionarioService {

    private final CuestionarioMapper cuestionarioMapper;
    private final CuestionarioRepository cuestionarioRepository;

    public CuestionarioServiceImpl(CuestionarioMapper cuestionarioMapper, CuestionarioRepository cuestionarioRepository) {
        this.cuestionarioMapper = cuestionarioMapper;
        this.cuestionarioRepository = cuestionarioRepository;
    }

    @Override
    public List<CuestionarioDTO> obtenerCuestionarios() {
        List<Cuestionario> cuestionarios = cuestionarioRepository.findAll();
        return cuestionarioMapper.toDto(cuestionarios);
    }

    @Override
    public Optional<CuestionarioDTO> obtenerCuestionarioPorId(Long id) {
        return  cuestionarioRepository
                .findById(id)
                .map(cuestionarioMapper::toDTO);
    }

    @Override
    @Transactional
    public CuestionarioDTO crearCuestionario(CuestionarioDTO cuestionarioDTO) {
        Cuestionario cuestionario = cuestionarioMapper.toEntity(cuestionarioDTO);
        cuestionario = cuestionarioRepository.save(cuestionario);
        return cuestionarioMapper.toDTO(cuestionario);
    }

    @Override
    @Transactional
    public List<PreguntaCuestionarioDTO> anadePreguntaEnCuestionario(Long cuestionarioId, PreguntaCuestionarioDTO preguntaCuestionarioDTO) {
        CuestionarioDTO cuestionarioDTO = obtenerCuestionarioPorId(cuestionarioId)
                .orElseThrow(() -> new RuntimeException("Cuestionario no encontrado"));

        preguntaCuestionarioDTO.setCuestionarioId(cuestionarioId);
        cuestionarioDTO.getPreguntas().add(preguntaCuestionarioDTO);
        Cuestionario cuestionario = cuestionarioRepository.save(cuestionarioMapper.toEntity(cuestionarioDTO));
        cuestionarioDTO = cuestionarioMapper.toDTO(cuestionario);
        return cuestionarioDTO.getPreguntas();
    }

    @Override
    @Transactional(readOnly = true)
    public List<PreguntaCuestionarioDTO> obtenerPreguntaCuestionario(Long cuestionarioId) {
        CuestionarioDTO cuestionarioDTO = obtenerCuestionarioPorId(cuestionarioId)
                .orElseThrow(() -> new RuntimeException("Cuestionario no encontrado"));

        return cuestionarioDTO.getPreguntas();

    }
}
