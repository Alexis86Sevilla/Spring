package com.kreitek.school.application.mapper;

import com.kreitek.school.application.dto.CuestionarioDTO;
import com.kreitek.school.domain.entity.Cuestionario;
import com.kreitek.school.domain.entity.PreguntaCuestionario;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring", uses = {PreguntaCuestionario.class})
public interface CuestionarioMapper extends EntityMapper<CuestionarioDTO, Cuestionario>{

    default Cuestionario fromId(Long id){
        if (id == null) return null;
        Cuestionario cuestionario = new Cuestionario();
        cuestionario.setId(id);
        return cuestionario;
    }
}
