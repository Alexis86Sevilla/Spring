package com.kreitek.school.application.mapper;

import com.kreitek.school.application.dto.CursoDTO;
import com.kreitek.school.application.dto.CursoSimpleDTO;
import com.kreitek.school.domain.entity.Curso;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring", uses = {LeccionMapper.class, AlumnoMapper.class})
public interface CursoMapper extends EntityMapper<CursoDTO, Curso>{
//INTERFAZ ESPECIFICA DE CURSO

    default Curso fromId(Long id){
        if (id == null) return null; //SI EL CURSO NO RECIBE ID DEVUELVE NULO
        Curso curso = new Curso(); //SI LO RECIBE, DEVOLVERA UN CURSO CON ID
        curso.setId(id);
        return curso;
    }

    @Mapping(target = "resumen", ignore = true)
    @Mapping(target = "lecciones", ignore = true)
    @Mapping(target = "alumnos", ignore = true)
    Curso toEntity(CursoSimpleDTO cursoSimpleDTO);
    CursoSimpleDTO toSimpleDTO(Curso curso);
}
