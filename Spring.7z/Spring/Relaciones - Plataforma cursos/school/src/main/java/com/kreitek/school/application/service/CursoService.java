package com.kreitek.school.application.service;

import com.kreitek.school.application.dto.CursoDTO;

import java.util.List;
import java.util.Optional;

public interface CursoService {
    //INTERFAZ QUE TENDRA LOS METODOS USADOS POR LA IMPLEMENTACION DE CURSOSSERVICEIMPL
    List<CursoDTO> obtenerCursos();
    Optional<CursoDTO> obtenerCurso(Long id);
    CursoDTO crearCurso(CursoDTO cursoDTO);
    void eliminarCurso(Long id);
}
