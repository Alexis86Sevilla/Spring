package com.example.mvn.hola.mvnhola;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MvnHolaApplication {

	public static void main(String[] args) {
		SpringApplication.run(MvnHolaApplication.class, args);
	}

}
