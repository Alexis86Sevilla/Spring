package com.example.mvn.hola.mvnhola;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MvnHolaApplicationTests {

	@Test
	void contextLoads() {
	}

}
