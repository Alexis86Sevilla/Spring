package com.example.hello.gradlehello;


import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloController {

    @GetMapping("/hola")
    public ResponseEntity<String> hello(){
        return ResponseEntity.ok("Hola Gradle");
    }

}
