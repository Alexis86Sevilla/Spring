package com.example.hello.gradlehello;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GradleHelloApplicationTests {

	@Test
	void contextLoads() {
	}

}
